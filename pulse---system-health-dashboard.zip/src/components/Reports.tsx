import React from 'react';
import { BarChart3, Download, Calendar, TrendingUp, ShieldAlert, Zap } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

const reportData = [
  { name: 'Mon', cpu: 45, mem: 62, alerts: 2 },
  { name: 'Tue', cpu: 52, mem: 58, alerts: 5 },
  { name: 'Wed', cpu: 48, mem: 65, alerts: 1 },
  { name: 'Thu', cpu: 61, mem: 72, alerts: 8 },
  { name: 'Fri', cpu: 55, mem: 68, alerts: 3 },
  { name: 'Sat', cpu: 42, mem: 55, alerts: 0 },
  { name: 'Sun', cpu: 38, mem: 50, alerts: 0 },
];

export function Reports() {
  return (
    <div className="space-y-6">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-white tracking-tight">System Reports</h1>
          <p className="text-gray-400 mt-1">Weekly performance analysis and health trends.</p>
        </div>
        <div className="flex gap-3">
          <button className="bg-[#2a2b2e] text-gray-300 px-4 py-2 rounded-lg border border-[#3a3b3e] flex items-center gap-2 hover:text-white transition-colors">
            <Calendar className="w-4 h-4" />
            Last 7 Days
          </button>
          <button className="bg-orange-500 text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2 hover:bg-orange-600 transition-colors">
            <Download className="w-4 h-4" />
            Download PDF
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#1c1d21] border border-[#2a2b2e] rounded-xl p-6">
          <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-orange-500" />
            Performance Trends
          </h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={reportData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2a2b2e" vertical={false} />
                <XAxis 
                  dataKey="name" 
                  stroke="#6b7280" 
                  fontSize={12} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <YAxis 
                  stroke="#6b7280" 
                  fontSize={12} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1c1d21', border: '1px solid #2a2b2e', borderRadius: '8px' }}
                  itemStyle={{ fontSize: '12px' }}
                />
                <Legend iconType="circle" wrapperStyle={{ paddingTop: '20px' }} />
                <Bar dataKey="cpu" name="Avg CPU %" fill="#f97316" radius={[4, 4, 0, 0]} />
                <Bar dataKey="mem" name="Avg Memory %" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-[#1c1d21] border border-[#2a2b2e] rounded-xl p-6">
            <h3 className="text-sm font-bold text-gray-500 uppercase tracking-widest mb-4">Summary</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-orange-500/10 rounded-lg">
                    <Zap className="w-4 h-4 text-orange-500" />
                  </div>
                  <span className="text-sm text-gray-300">Peak CPU</span>
                </div>
                <span className="text-white font-mono font-bold">84%</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <Database className="w-4 h-4 text-blue-500" />
                  </div>
                  <span className="text-sm text-gray-300">Peak Memory</span>
                </div>
                <span className="text-white font-mono font-bold">78%</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-red-500/10 rounded-lg">
                    <ShieldAlert className="w-4 h-4 text-red-500" />
                  </div>
                  <span className="text-sm text-gray-300">Total Alerts</span>
                </div>
                <span className="text-white font-mono font-bold">19</span>
              </div>
            </div>
          </div>

          <div className="bg-orange-500/5 border border-orange-500/20 rounded-xl p-6">
            <h3 className="text-orange-500 font-bold mb-2">AI Insights</h3>
            <p className="text-sm text-gray-400 leading-relaxed">
              Based on this week's data, your system experiences peak load on Thursdays. 
              We recommend scheduling non-critical maintenance for Sundays to optimize performance.
            </p>
            <button className="mt-4 text-xs font-bold text-orange-500 hover:underline flex items-center gap-1">
              View Optimization Plan <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

import { Database, ArrowRight } from 'lucide-react';
