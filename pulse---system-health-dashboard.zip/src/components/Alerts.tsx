import React from 'react';
import { Bell, AlertCircle, AlertTriangle, ShieldAlert, CheckCircle2, Clock, Filter } from 'lucide-react';
import { cn } from '@/src/lib/utils';

const mockAlerts = [
  { id: '1', type: 'critical', title: 'CPU Overload', message: 'CPU usage exceeded 90% for more than 5 minutes.', time: '10 mins ago', status: 'active' },
  { id: '2', type: 'warning', title: 'Memory Pressure', message: 'Available memory dropped below 15%.', time: '45 mins ago', status: 'active' },
  { id: '3', type: 'critical', title: 'Disk Space Critical', message: 'Root partition has less than 2GB remaining.', time: '2 hours ago', status: 'resolved' },
  { id: '4', type: 'info', title: 'System Update', message: 'A new security patch is available for installation.', time: '5 hours ago', status: 'active' },
];

export function Alerts() {
  return (
    <div className="space-y-6">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-white tracking-tight">Active Alerts</h1>
          <p className="text-gray-400 mt-1">Monitor and manage system notifications and critical events.</p>
        </div>
        <div className="flex gap-3">
          <button className="bg-[#2a2b2e] text-gray-300 px-4 py-2 rounded-lg border border-[#3a3b3e] flex items-center gap-2 hover:text-white transition-colors">
            <CheckCircle2 className="w-4 h-4" />
            Mark All Resolved
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-4">
        {mockAlerts.map((alert) => (
          <div 
            key={alert.id}
            className={cn(
              "p-5 rounded-xl border flex gap-5 transition-all",
              alert.status === 'resolved' 
                ? "bg-[#1c1d21]/50 border-[#2a2b2e] opacity-60" 
                : "bg-[#1c1d21] border-[#2a2b2e] hover:border-[#3a3b3e]"
            )}
          >
            <div className={cn(
              "w-12 h-12 rounded-xl flex items-center justify-center shrink-0",
              alert.type === 'critical' && "bg-red-500/10 text-red-500",
              alert.type === 'warning' && "bg-yellow-500/10 text-yellow-500",
              alert.type === 'info' && "bg-blue-500/10 text-blue-500"
            )}>
              {alert.type === 'critical' ? <ShieldAlert className="w-6 h-6" /> : 
               alert.type === 'warning' ? <AlertTriangle className="w-6 h-6" /> : 
               <Bell className="w-6 h-6" />}
            </div>

            <div className="flex-1 space-y-1">
              <div className="flex justify-between items-start">
                <h3 className={cn(
                  "font-bold text-lg",
                  alert.status === 'resolved' ? "text-gray-500" : "text-white"
                )}>
                  {alert.title}
                </h3>
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <Clock className="w-3 h-3" />
                  {alert.time}
                </div>
              </div>
              <p className="text-gray-400 text-sm">{alert.message}</p>
              
              <div className="pt-3 flex gap-3">
                {alert.status === 'active' ? (
                  <>
                    <button className="text-xs font-bold text-orange-500 hover:underline">Acknowledge</button>
                    <button className="text-xs font-bold text-gray-500 hover:text-gray-300">View Details</button>
                  </>
                ) : (
                  <span className="text-xs font-bold text-green-500 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Resolved
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
