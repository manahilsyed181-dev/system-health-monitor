import React, { useState } from 'react';
import { Save, Bell, Shield, Cpu, Database, HardDrive, Thermometer } from 'lucide-react';
import { AlertThresholds } from '../types';

export function Settings() {
  const [thresholds, setThresholds] = useState<AlertThresholds>({
    cpu: 80,
    memory: 75,
    disk: 90,
    temp: 70
  });

  const handleSave = () => {
    // In a real app, this would save to Firestore
    alert('Settings saved successfully!');
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-white tracking-tight">System Settings</h1>
          <p className="text-gray-400 mt-1">Configure monitoring thresholds and notification preferences.</p>
        </div>
        <button 
          onClick={handleSave}
          className="bg-orange-500 text-white px-6 py-2 rounded-lg font-bold flex items-center gap-2 hover:bg-orange-600 transition-colors"
        >
          <Save className="w-4 h-4" />
          Save Changes
        </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-[#1c1d21] border border-[#2a2b2e] rounded-xl p-6 space-y-6">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <Bell className="w-5 h-5 text-orange-500" />
            Alert Thresholds
          </h3>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <label className="text-gray-400 flex items-center gap-2">
                  <Cpu className="w-4 h-4" /> CPU Usage (%)
                </label>
                <span className="text-orange-500 font-mono">{thresholds.cpu}%</span>
              </div>
              <input 
                type="range" min="0" max="100" 
                value={thresholds.cpu}
                onChange={(e) => setThresholds({...thresholds, cpu: parseInt(e.target.value)})}
                className="w-full accent-orange-500"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <label className="text-gray-400 flex items-center gap-2">
                  <Database className="w-4 h-4" /> Memory Usage (%)
                </label>
                <span className="text-blue-500 font-mono">{thresholds.memory}%</span>
              </div>
              <input 
                type="range" min="0" max="100" 
                value={thresholds.memory}
                onChange={(e) => setThresholds({...thresholds, memory: parseInt(e.target.value)})}
                className="w-full accent-blue-500"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <label className="text-gray-400 flex items-center gap-2">
                  <HardDrive className="w-4 h-4" /> Disk Usage (%)
                </label>
                <span className="text-green-500 font-mono">{thresholds.disk}%</span>
              </div>
              <input 
                type="range" min="0" max="100" 
                value={thresholds.disk}
                onChange={(e) => setThresholds({...thresholds, disk: parseInt(e.target.value)})}
                className="w-full accent-green-500"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <label className="text-gray-400 flex items-center gap-2">
                  <Thermometer className="w-4 h-4" /> Temperature (°C)
                </label>
                <span className="text-red-500 font-mono">{thresholds.temp}°C</span>
              </div>
              <input 
                type="range" min="0" max="100" 
                value={thresholds.temp}
                onChange={(e) => setThresholds({...thresholds, temp: parseInt(e.target.value)})}
                className="w-full accent-red-500"
              />
            </div>
          </div>
        </div>

        <div className="bg-[#1c1d21] border border-[#2a2b2e] rounded-xl p-6 space-y-6">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <Shield className="w-5 h-5 text-blue-500" />
            Security & Access
          </h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-lg bg-[#2a2b2e]/50">
              <div>
                <p className="text-sm font-medium text-gray-200">Two-Factor Authentication</p>
                <p className="text-xs text-gray-500">Add an extra layer of security</p>
              </div>
              <div className="w-10 h-5 bg-orange-500 rounded-full relative cursor-pointer">
                <div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full" />
              </div>
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg bg-[#2a2b2e]/50">
              <div>
                <p className="text-sm font-medium text-gray-200">Email Notifications</p>
                <p className="text-xs text-gray-500">Receive alerts via email</p>
              </div>
              <div className="w-10 h-5 bg-[#3a3b3e] rounded-full relative cursor-pointer">
                <div className="absolute left-1 top-1 w-3 h-3 bg-white rounded-full" />
              </div>
            </div>

            <div className="pt-4 space-y-3">
              <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">API Access</p>
              <div className="flex gap-2">
                <input 
                  type="password" 
                  value="sk_live_51Mz..." 
                  readOnly
                  className="flex-1 bg-[#2a2b2e] border border-[#3a3b3e] rounded-lg px-3 py-2 text-sm text-gray-400 font-mono"
                />
                <button className="bg-[#2a2b2e] text-gray-300 px-3 py-2 rounded-lg border border-[#3a3b3e] text-xs hover:text-white">
                  Regenerate
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
