import React from 'react';
import { LayoutDashboard, ListTree, Bell, BarChart3, Settings, ShieldCheck, LogOut } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'logs', label: 'System Logs', icon: ListTree },
  { id: 'alerts', label: 'Alerts', icon: Bell },
  { id: 'reports', label: 'Reports', icon: BarChart3 },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  return (
    <div className="w-64 bg-[#151619] border-r border-[#2a2b2e] flex flex-col h-screen sticky top-0">
      <div className="p-6 flex items-center gap-3 border-bottom border-[#2a2b2e]">
        <div className="w-8 h-8 bg-orange-500 rounded flex items-center justify-center">
          <ShieldCheck className="text-white w-5 h-5" />
        </div>
        <span className="text-white font-bold text-xl tracking-tight">PULSE</span>
      </div>
      
      <nav className="flex-1 px-4 py-6 space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 group",
              activeTab === item.id 
                ? "bg-orange-500/10 text-orange-500" 
                : "text-gray-400 hover:bg-[#2a2b2e] hover:text-white"
            )}
          >
            <item.icon className={cn(
              "w-5 h-5",
              activeTab === item.id ? "text-orange-500" : "text-gray-500 group-hover:text-white"
            )} />
            <span className="font-medium">{item.label}</span>
            {item.id === 'alerts' && (
              <span className="ml-auto bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">3</span>
            )}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-[#2a2b2e]">
        <button className="w-full flex items-center gap-3 px-4 py-3 text-gray-400 hover:text-white transition-colors">
          <LogOut className="w-5 h-5" />
          <span className="font-medium">Logout</span>
        </button>
      </div>
    </div>
  );
}
