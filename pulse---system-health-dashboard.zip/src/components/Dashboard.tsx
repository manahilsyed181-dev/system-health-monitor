import React, { useEffect, useState } from 'react';
import { Cpu, Database, HardDrive, Thermometer, Activity, Server, Clock } from 'lucide-react';
import { MetricCard } from './MetricCard';
import { SystemMetrics } from '../types';
import { motion } from 'motion/react';

export function Dashboard() {
  const [metrics, setMetrics] = useState<SystemMetrics | null>(null);

  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const res = await fetch('/api/metrics');
        const data = await res.json();
        setMetrics(data);
      } catch (err) {
        console.error('Failed to fetch metrics:', err);
      }
    };

    fetchMetrics();
    const interval = setInterval(fetchMetrics, 3000);
    return () => clearInterval(interval);
  }, []);

  if (!metrics) return (
    <div className="flex items-center justify-center h-full">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500"></div>
    </div>
  );

  return (
    <div className="space-y-8">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-white tracking-tight">System Overview</h1>
          <p className="text-gray-400 mt-1">Real-time performance monitoring and diagnostics.</p>
        </div>
        <div className="flex gap-4">
          <div className="bg-[#1c1d21] px-4 py-2 rounded-lg border border-[#2a2b2e] flex items-center gap-3">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-sm font-mono text-gray-300 uppercase tracking-widest">System Online</span>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="CPU Usage"
          value={metrics.cpu.current}
          unit="%"
          history={metrics.cpu.history}
          color="#f97316"
          icon={<Cpu className="w-5 h-5" />}
          trend="+2.4%"
        />
        <MetricCard
          title="Memory Usage"
          value={metrics.memory.current}
          unit="%"
          history={metrics.memory.history}
          color="#3b82f6"
          icon={<Database className="w-5 h-5" />}
          trend="-1.2%"
        />
        <MetricCard
          title="Disk Space"
          value={metrics.disk.used}
          unit="%"
          history={[60, 61, 62, 63, 64, 65]}
          color="#10b981"
          icon={<HardDrive className="w-5 h-5" />}
        />
        <MetricCard
          title="CPU Temp"
          value={metrics.cpu.temp}
          unit="°C"
          history={[42, 44, 45, 43, 46, 45]}
          color="#ef4444"
          icon={<Thermometer className="w-5 h-5" />}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#1c1d21] border border-[#2a2b2e] rounded-xl p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-orange-500" />
              Process Monitor
            </h3>
            <button className="text-xs text-orange-500 hover:underline">View All</button>
          </div>
          
          <div className="space-y-4">
            {[
              { name: 'nginx-worker', cpu: '1.2%', mem: '45MB', status: 'running' },
              { name: 'node-server', cpu: '14.5%', mem: '256MB', status: 'running' },
              { name: 'postgres-db', cpu: '0.8%', mem: '1.2GB', status: 'running' },
              { name: 'redis-cache', cpu: '0.2%', mem: '12MB', status: 'running' },
            ].map((proc, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-[#2a2b2e]/50 border border-transparent hover:border-[#3a3b3e] transition-all">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-[#2a2b2e] rounded flex items-center justify-center text-xs font-mono text-gray-400">
                    {proc.name[0].toUpperCase()}
                  </div>
                  <span className="text-gray-200 font-medium">{proc.name}</span>
                </div>
                <div className="flex gap-8 text-sm font-mono">
                  <div className="flex flex-col items-end">
                    <span className="text-gray-500 text-[10px] uppercase">CPU</span>
                    <span className="text-orange-400">{proc.cpu}</span>
                  </div>
                  <div className="flex flex-col items-end">
                    <span className="text-gray-500 text-[10px] uppercase">MEM</span>
                    <span className="text-blue-400">{proc.mem}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#1c1d21] border border-[#2a2b2e] rounded-xl p-6">
          <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
            <Server className="w-5 h-5 text-blue-500" />
            Server Info
          </h3>
          
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3 text-gray-400">
                <Clock className="w-4 h-4" />
                <span className="text-sm">Uptime</span>
              </div>
              <span className="text-white font-mono text-sm">
                {Math.floor(metrics.uptime / 3600)}h {Math.floor((metrics.uptime % 3600) / 60)}m
              </span>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-gray-500 uppercase tracking-wider">
                <span>Disk Usage</span>
                <span>{metrics.disk.used}%</span>
              </div>
              <div className="h-1.5 bg-[#2a2b2e] rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${metrics.disk.used}%` }}
                  className="h-full bg-green-500" 
                />
              </div>
            </div>

            <div className="pt-4 border-t border-[#2a2b2e] space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">OS</span>
                <span className="text-gray-200">Ubuntu 22.04 LTS</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Kernel</span>
                <span className="text-gray-200">5.15.0-generic</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Region</span>
                <span className="text-gray-200">US-East-1</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
