import React from 'react';
import { ResponsiveContainer, AreaChart, Area } from 'recharts';
import { cn } from '@/src/lib/utils';

interface MetricCardProps {
  title: string;
  value: string | number;
  unit: string;
  history: number[];
  color: string;
  icon: React.ReactNode;
  trend?: string;
  status?: 'normal' | 'warning' | 'critical';
}

export function MetricCard({ title, value, unit, history, color, icon, trend, status = 'normal' }: MetricCardProps) {
  const chartData = history.map((val, i) => ({ value: val, index: i }));

  return (
    <div className="bg-[#1c1d21] border border-[#2a2b2e] rounded-xl p-5 hover:border-[#3a3b3e] transition-all group">
      <div className="flex justify-between items-start mb-4">
        <div className="p-2 bg-[#2a2b2e] rounded-lg text-gray-400 group-hover:text-white transition-colors">
          {icon}
        </div>
        {trend && (
          <span className={cn(
            "text-xs font-mono px-2 py-1 rounded",
            trend.startsWith('+') ? "text-red-400 bg-red-400/10" : "text-green-400 bg-green-400/10"
          )}>
            {trend}
          </span>
        )}
      </div>
      
      <div className="space-y-1">
        <h3 className="text-gray-400 text-sm font-medium">{title}</h3>
        <div className="flex items-baseline gap-1">
          <span className="text-2xl font-bold text-white font-mono">{value}</span>
          <span className="text-gray-500 text-sm">{unit}</span>
        </div>
      </div>

      <div className="h-16 mt-4 -mx-2">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id={`gradient-${title}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={color} stopOpacity={0.3}/>
                <stop offset="95%" stopColor={color} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <Area
              type="monotone"
              dataKey="value"
              stroke={color}
              strokeWidth={2}
              fillOpacity={1}
              fill={`url(#gradient-${title})`}
              isAnimationActive={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
