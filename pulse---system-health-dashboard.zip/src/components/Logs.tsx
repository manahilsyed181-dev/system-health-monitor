import React, { useState } from 'react';
import { Search, Filter, Download, Trash2, AlertCircle, Info, AlertTriangle, XCircle } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { LogEntry } from '../types';

const mockLogs: LogEntry[] = [
  { id: '1', timestamp: '2026-04-10T07:45:12Z', level: 'info', message: 'System boot sequence completed successfully', source: 'kernel' },
  { id: '2', timestamp: '2026-04-10T07:46:05Z', level: 'warning', message: 'High memory usage detected in node-server', source: 'monitor' },
  { id: '3', timestamp: '2026-04-10T07:47:22Z', level: 'error', message: 'Failed to connect to redis-cache: Connection timeout', source: 'app' },
  { id: '4', timestamp: '2026-04-10T07:48:10Z', level: 'info', message: 'Database backup initiated', source: 'backup-mgr' },
  { id: '5', timestamp: '2026-04-10T07:49:01Z', level: 'critical', message: 'Disk space critical: < 5% remaining on /dev/sda1', source: 'storage' },
  { id: '6', timestamp: '2026-04-10T07:50:15Z', level: 'info', message: 'User admin logged in from 192.168.1.105', source: 'auth' },
];

export function Logs() {
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  const getLevelIcon = (level: string) => {
    switch (level) {
      case 'info': return <Info className="w-4 h-4 text-blue-400" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
      case 'error': return <AlertCircle className="w-4 h-4 text-red-400" />;
      case 'critical': return <XCircle className="w-4 h-4 text-red-600" />;
      default: return null;
    }
  };

  const filteredLogs = mockLogs.filter(log => {
    const matchesFilter = filter === 'all' || log.level === filter;
    const matchesSearch = log.message.toLowerCase().includes(search.toLowerCase()) || 
                         log.source.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-white tracking-tight">System Logs</h1>
          <p className="text-gray-400 mt-1">Historical record of system events and errors.</p>
        </div>
        <div className="flex gap-3">
          <button className="bg-[#2a2b2e] text-gray-300 px-4 py-2 rounded-lg border border-[#3a3b3e] flex items-center gap-2 hover:text-white transition-colors">
            <Download className="w-4 h-4" />
            Export
          </button>
          <button className="bg-red-500/10 text-red-500 px-4 py-2 rounded-lg border border-red-500/20 flex items-center gap-2 hover:bg-red-500/20 transition-colors">
            <Trash2 className="w-4 h-4" />
            Clear Logs
          </button>
        </div>
      </header>

      <div className="bg-[#1c1d21] border border-[#2a2b2e] rounded-xl overflow-hidden">
        <div className="p-4 border-b border-[#2a2b2e] flex flex-wrap gap-4 items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input 
              type="text" 
              placeholder="Search logs..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-[#2a2b2e] border border-[#3a3b3e] rounded-lg py-2 pl-10 pr-4 text-sm text-white focus:outline-none focus:border-orange-500 transition-colors"
            />
          </div>
          
          <div className="flex gap-2">
            {['all', 'info', 'warning', 'error', 'critical'].map((lvl) => (
              <button
                key={lvl}
                onClick={() => setFilter(lvl)}
                className={cn(
                  "px-3 py-1.5 rounded-md text-xs font-medium capitalize transition-all",
                  filter === lvl 
                    ? "bg-orange-500 text-white" 
                    : "bg-[#2a2b2e] text-gray-400 hover:text-white"
                )}
              >
                {lvl}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[#2a2b2e]/30 text-gray-500 text-[10px] uppercase tracking-widest font-bold">
                <th className="px-6 py-3 border-b border-[#2a2b2e]">Timestamp</th>
                <th className="px-6 py-3 border-b border-[#2a2b2e]">Level</th>
                <th className="px-6 py-3 border-b border-[#2a2b2e]">Source</th>
                <th className="px-6 py-3 border-b border-[#2a2b2e]">Message</th>
              </tr>
            </thead>
            <tbody className="text-sm font-mono">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-[#2a2b2e]/20 transition-colors group">
                  <td className="px-6 py-4 border-b border-[#2a2b2e] text-gray-500 whitespace-nowrap">
                    {new Date(log.timestamp).toLocaleTimeString()}
                  </td>
                  <td className="px-6 py-4 border-b border-[#2a2b2e]">
                    <div className="flex items-center gap-2">
                      {getLevelIcon(log.level)}
                      <span className={cn(
                        "capitalize",
                        log.level === 'info' && "text-blue-400",
                        log.level === 'warning' && "text-yellow-400",
                        log.level === 'error' && "text-red-400",
                        log.level === 'critical' && "text-red-600 font-bold"
                      )}>
                        {log.level}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 border-b border-[#2a2b2e] text-gray-400">
                    {log.source}
                  </td>
                  <td className="px-6 py-4 border-b border-[#2a2b2e] text-gray-200">
                    {log.message}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
