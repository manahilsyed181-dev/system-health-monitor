export interface SystemMetrics {
  cpu: {
    current: number;
    history: number[];
    cores: number;
    temp: number;
  };
  memory: {
    current: number;
    history: number[];
    total: number;
    used: number;
  };
  disk: {
    used: number;
    total: number;
    read: number;
    write: number;
  };
  status: 'online' | 'offline' | 'warning';
  uptime: number;
  timestamp: string;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  level: 'info' | 'warning' | 'error' | 'critical';
  message: string;
  source: string;
}

export interface AlertThresholds {
  cpu: number;
  memory: number;
  disk: number;
  temp: number;
}
