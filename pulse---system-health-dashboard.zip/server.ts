import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Mock System Metrics API
  let cpuHistory: number[] = Array(20).fill(0).map(() => Math.floor(Math.random() * 40) + 10);
  let memHistory: number[] = Array(20).fill(0).map(() => Math.floor(Math.random() * 30) + 40);

  app.get('/api/metrics', (req, res) => {
    const currentCpu = Math.floor(Math.random() * 40) + 10;
    const currentMem = Math.floor(Math.random() * 30) + 40;
    
    cpuHistory.push(currentCpu);
    if (cpuHistory.length > 20) cpuHistory.shift();
    
    memHistory.push(currentMem);
    if (memHistory.length > 20) memHistory.shift();

    res.json({
      cpu: {
        current: currentCpu,
        history: cpuHistory,
        cores: 8,
        temp: 45 + Math.floor(Math.random() * 10)
      },
      memory: {
        current: currentMem,
        history: memHistory,
        total: 16384, // MB
        used: Math.floor(16384 * (currentMem / 100))
      },
      disk: {
        used: 65,
        total: 512, // GB
        read: 12.5,
        write: 4.2
      },
      status: 'online',
      uptime: process.uptime(),
      timestamp: new Date().toISOString()
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
